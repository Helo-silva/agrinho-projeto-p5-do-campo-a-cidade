function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let predios = [];

let ruas = [];

let arvores = [];

let caminhao;

let nuvens = [];

let corCeu = 135;

let passaros = [];

function setup() {

  createCanvas(800, 600);

  // Criar prédios com alinhamento na base

  for (let i = 0; i < 5; i++) {

    let largura = 60;

    let altura = random(150, 300);

    predios.push({

      x: i * (largura + 20) + 50,

      y: height - altura - 100,

      largura: largura,

      altura: altura

    });

  }

  // Criar ruas

  ruas.push({ x: 0, y: height - 100, largura: width, altura: 100 });

  // Criar árvores alinhadas

  for (let i = 0; i < 6; i++) {

    arvores.push({

      x: i * 120 + 60,

      y: height - 130,

      troncoLargura: 20,

      troncoAltura: 30,

      copaDiametro: 50

    });

  }

  // Caminhão

  caminhao = {

    x: 0,

    y: height - 80,

    largura: 100,

    altura: 40,

    velocidade: 2

  };

  // Nuvens

  for (let i = 0; i < 3; i++) {

    nuvens.push({ x: random(width), y: random(50, 150), velocidade: random(0.5, 1) });

  }

  // Pássaros

  for (let i = 0; i < 5; i++) {

    passaros.push({ x: random(width), y: random(30, 100), velocidade: random(1, 2) });

  }

}

function draw() {

  background(corCeu, 206, 235);

  // Escurecer o céu com o tempo

  corCeu -= 0.02;

  if (corCeu < 20) corCeu = 135;

  // Sol

  fill(255, 255, 0);

  noStroke();

  ellipse(700, 100, 150, 150);

  // Nuvens

  for (let nuvem of nuvens) {

    fill(255);

    ellipse(nuvem.x, nuvem.y, 60, 40);

    ellipse(nuvem.x + 30, nuvem.y + 10, 50, 30);

    ellipse(nuvem.x - 30, nuvem.y + 10, 50, 30);

    nuvem.x += nuvem.velocidade;

    if (nuvem.x > width + 60) nuvem.x = -60;

  }

  // Pássaros

  stroke(0);

  for (let p of passaros) {

    drawPassaro(p.x, p.y);

    p.x += p.velocidade;

    if (p.x > width) p.x = -10;

  }

  noStroke();

  // Prédios

  for (let i = 0; i < predios.length; i++) {

    fill(143, 166, 178);

    rect(predios[i].x, predios[i].y, predios[i].largura, predios[i].altura);

    // Janelas

    for (let j = 10; j < predios[i].altura - 20; j += 30) {

      for (let k = 10; k < predios[i].largura - 10; k += 25) {

        fill(255, 255, 153);

        rect(predios[i].x + k, predios[i].y + j, 15, 15);

      }

    }

    // Sombra

    fill(100, 100, 100, 100);

    quad(

      predios[i].x + predios[i].largura, predios[i].y,

      predios[i].x + predios[i].largura + 20, predios[i].y + 20,

      predios[i].x + predios[i].largura + 20, predios[i].y + predios[i].altura + 20,

      predios[i].x + predios[i].largura, predios[i].y + predios[i].altura

    );

  }

  // Ruas

  for (let i = 0; i < ruas.length; i++) {

    fill(64, 64, 64);

    rect(ruas[i].x, ruas[i].y, ruas[i].largura, ruas[i].altura);

    // Faixas

    for (let j = 0; j < width; j += 40) {

      fill(255);

      rect(j, ruas[i].y + 50, 20, 5);

    }

  }

  // Árvores

  for (let i = 0; i < arvores.length; i++) {

    let arv = arvores[i];

    fill(102, 51, 0);

    rect(arv.x, arv.y, arv.troncoLargura, arv.troncoAltura);

    fill(0, 128, 0);

    ellipse(arv.x + arv.troncoLargura / 2, arv.y, arv.copaDiametro, arv.copaDiametro);

  }

  // Caminhão

  fill(255, 0, 0);

  rect(caminhao.x, caminhao.y, caminhao.largura, caminhao.altura);

  // Janela e cabine

  fill(200);

  rect(caminhao.x + 60, caminhao.y + 5, 30, 20);

  fill(150, 0, 0);

  rect(caminhao.x + 70, caminhao.y - 10, 20, 10);

  // Rodas

  fill(0);

  ellipse(caminhao.x + 20, caminhao.y + caminhao.altura, 20, 20);

  ellipse(caminhao.x + caminhao.largura - 20, caminhao.y + caminhao.altura, 20, 20);

  // Mover caminhão

  caminhao.x += caminhao.velocidade;

  if (caminhao.x > width) {

    caminhao.x = -caminhao.largura;

  }

}

// Função auxiliar para desenhar pássaros

function drawPassaro(x, y) {

  beginShape();

  vertex(x, y);

  vertex(x + 5, y - 5);

  vertex(x + 10, y);

  endShape();

}


